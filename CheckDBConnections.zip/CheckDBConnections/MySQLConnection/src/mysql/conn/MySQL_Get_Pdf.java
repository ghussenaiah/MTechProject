package mysql.conn;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.DriverManager;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class MySQL_Get_Pdf {

	

	public static void main(String args[]){  
		try{  
			  byte[] fileBytes;
		Class.forName("com.mysql.jdbc.Driver");  
		  
		Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Test","root","root");  
		  
		
		String sql="select pdf from PdfFile1 where name='testpdf'";
		PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
		
				ResultSet rs=(ResultSet) ps.executeQuery();
	
		if (rs.next()) {
            fileBytes = rs.getBytes(1);
            OutputStream targetFile=  new FileOutputStream("k://project//newtest1.pdf");
            targetFile.write(fileBytes);
            System.out.println("ok");
            targetFile.close();
        }
	
		}catch(Exception e){ System.out.println(e);}  
		  
		}  

}
