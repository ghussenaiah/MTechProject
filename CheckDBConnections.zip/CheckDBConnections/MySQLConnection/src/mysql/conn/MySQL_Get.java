package mysql.conn;

import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class MySQL_Get {

	
	public static void main(String args[]){  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		  
		Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");  
		  
		String sql="select * from student";
		//Statement stmt=(Statement) con.createStatement();  
		// String sql = "INSERT INTO STUDENT " +
		//		"(ID, NAME, EMAIL,ADDRESS) VALUES (11, 'Gandham', 'g@gmail.com', 'mbnr')";
		//java.sql.ResultSet i=stmt.executeQuery(sql);  
		 PreparedStatement ps= (PreparedStatement) con.prepareStatement(sql);
		  
		 ResultSet rs=(ResultSet) ps.executeQuery();
		 System.out.println("rs: "+rs);
		 int numcols = rs.getMetaData().getColumnCount();
		 System.out.println("no of columns"+numcols);
		 
		

		// List<String> arrayList = new ArrayList<String>(); 
		 Collection arrayList= new ArrayList(); 
		// List<Integer> arrayList = new ArrayList<Integer>(); 
		 while (rs.next()) {              
		        int i = 1;
		         while(i <= numcols) {
		             arrayList.add(rs.getString(i++));
		         }
		        
		 }

		 System.out.println("List value before sort: "+arrayList);
		// Collections.sort(arrayList);
		 
		 System.out.println("List value after sort: "+arrayList);
		 for (Object str : arrayList) {
				System.out.println(str);
		 }
		}catch(Exception e){ System.out.println(e);}  
		  
		}  
}
