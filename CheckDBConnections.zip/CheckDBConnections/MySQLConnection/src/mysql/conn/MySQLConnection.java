package mysql.conn;

import java.sql.DriverManager;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class MySQLConnection {

	
	public static void main(String args[]){  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		  
		Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/TestDB","root","root");  
		  
		
		Statement stmt=(Statement) con.createStatement();  
		  
		ResultSet rs=(ResultSet) stmt.executeQuery("select * from TestTable");  
		  
		while(rs.next())  
		System.out.println(rs.getString(1)+"  "+rs.getString(2));  
		  
		con.close();  
		  
		}catch(Exception e){ System.out.println(e);}  
		  
		}  
}
