package mysql.conn;

import java.sql.DriverManager;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class MySQL_Insert {

	
	public static void main(String args[]){  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		  
		Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");  
		  
		
		//Statement stmt=(Statement) con.createStatement();  
		 String sql = "INSERT INTO STUDENT " +
				"(ID, NAME, EMAIL,ADDRESS) VALUES (11, 'Gandham', 'g@gmail.com', 'mbnr')";
		//java.sql.ResultSet i=stmt.executeQuery(sql);  
		 PreparedStatement ps= (PreparedStatement) con.prepareStatement(sql);
		  
		 int i=ps.executeUpdate();
		 con.close();
		  
		 System.out.println(i);
		  
		}catch(Exception e){ System.out.println(e);}  
		  
		}  
}
